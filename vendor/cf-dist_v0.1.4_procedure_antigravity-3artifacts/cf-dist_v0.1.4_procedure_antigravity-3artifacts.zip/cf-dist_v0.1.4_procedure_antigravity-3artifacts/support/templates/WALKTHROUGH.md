# Walkthrough（ウォークスルー / Antigravity互換）
> **実装完了後**に作る、「何を変えたか」「どうテストするか」をまとめた **変更サマリ＋検証手順**。

## 1. What changed（変更概要）
-

## 2. Files changed（差分一覧）
- Add:
  - 
- Modify:
  - 

## 3. How to test（検証手順）
1.
2.
3.

## 4. Evidence（証跡：あるとレビューが爆速）
- Code diffs（差分リンク / 主要差分の説明）：
- Screenshots（Before/After）：
- Browser recordings（操作録画）：

## 5. Known issues / Notes
-

## 6. Rollback（戻し方）
-
